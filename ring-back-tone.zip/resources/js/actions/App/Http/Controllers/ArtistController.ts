import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/artists',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtistController::index
 * @see app/Http/Controllers/ArtistController.php:16
 * @route '/artists'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/artists/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtistController::create
 * @see app/Http/Controllers/ArtistController.php:28
 * @route '/artists/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\ArtistController::store
 * @see app/Http/Controllers/ArtistController.php:36
 * @route '/artists'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/artists',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\ArtistController::store
 * @see app/Http/Controllers/ArtistController.php:36
 * @route '/artists'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::store
 * @see app/Http/Controllers/ArtistController.php:36
 * @route '/artists'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\ArtistController::store
 * @see app/Http/Controllers/ArtistController.php:36
 * @route '/artists'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtistController::store
 * @see app/Http/Controllers/ArtistController.php:36
 * @route '/artists'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
export const show = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/artists/{artist}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
show.url = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { artist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    artist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artist: typeof args.artist === 'object'
                ? args.artist.id
                : args.artist,
                }

    return show.definition.url
            .replace('{artist}', parsedArgs.artist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
show.get = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
show.head = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
    const showForm = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
        showForm.get = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtistController::show
 * @see app/Http/Controllers/ArtistController.php:50
 * @route '/artists/{artist}'
 */
        showForm.head = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
export const edit = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/artists/{artist}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
edit.url = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { artist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    artist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artist: typeof args.artist === 'object'
                ? args.artist.id
                : args.artist,
                }

    return edit.definition.url
            .replace('{artist}', parsedArgs.artist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
edit.get = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
edit.head = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
    const editForm = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
        editForm.get = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ArtistController::edit
 * @see app/Http/Controllers/ArtistController.php:58
 * @route '/artists/{artist}/edit'
 */
        editForm.head = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
export const update = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/artists/{artist}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
update.url = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { artist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    artist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artist: typeof args.artist === 'object'
                ? args.artist.id
                : args.artist,
                }

    return update.definition.url
            .replace('{artist}', parsedArgs.artist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
update.put = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
update.patch = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
    const updateForm = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
        updateForm.put = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\ArtistController::update
 * @see app/Http/Controllers/ArtistController.php:68
 * @route '/artists/{artist}'
 */
        updateForm.patch = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\ArtistController::destroy
 * @see app/Http/Controllers/ArtistController.php:80
 * @route '/artists/{artist}'
 */
export const destroy = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/artists/{artist}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\ArtistController::destroy
 * @see app/Http/Controllers/ArtistController.php:80
 * @route '/artists/{artist}'
 */
destroy.url = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { artist: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { artist: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    artist: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        artist: typeof args.artist === 'object'
                ? args.artist.id
                : args.artist,
                }

    return destroy.definition.url
            .replace('{artist}', parsedArgs.artist.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\ArtistController::destroy
 * @see app/Http/Controllers/ArtistController.php:80
 * @route '/artists/{artist}'
 */
destroy.delete = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\ArtistController::destroy
 * @see app/Http/Controllers/ArtistController.php:80
 * @route '/artists/{artist}'
 */
    const destroyForm = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\ArtistController::destroy
 * @see app/Http/Controllers/ArtistController.php:80
 * @route '/artists/{artist}'
 */
        destroyForm.delete = (args: { artist: number | { id: number } } | [artist: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const ArtistController = { index, create, store, show, edit, update, destroy }

export default ArtistController