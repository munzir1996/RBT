import DashboardController from './DashboardController'
import ArtistController from './ArtistController'
import SimController from './SimController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
ArtistController: Object.assign(ArtistController, ArtistController),
SimController: Object.assign(SimController, SimController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers