import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/sims',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SimController::index
 * @see app/Http/Controllers/SimController.php:16
 * @route '/sims'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/sims/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SimController::create
 * @see app/Http/Controllers/SimController.php:28
 * @route '/sims/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\SimController::store
 * @see app/Http/Controllers/SimController.php:36
 * @route '/sims'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/sims',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\SimController::store
 * @see app/Http/Controllers/SimController.php:36
 * @route '/sims'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::store
 * @see app/Http/Controllers/SimController.php:36
 * @route '/sims'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\SimController::store
 * @see app/Http/Controllers/SimController.php:36
 * @route '/sims'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SimController::store
 * @see app/Http/Controllers/SimController.php:36
 * @route '/sims'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
export const show = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})

show.definition = {
    methods: ["get","head"],
    url: '/sims/{sim}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
show.url = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sim: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sim: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sim: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sim: typeof args.sim === 'object'
                ? args.sim.id
                : args.sim,
                }

    return show.definition.url
            .replace('{sim}', parsedArgs.sim.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
show.get = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
show.head = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
    const showForm = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
        showForm.get = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SimController::show
 * @see app/Http/Controllers/SimController.php:50
 * @route '/sims/{sim}'
 */
        showForm.head = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show.form = showForm
/**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
export const edit = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/sims/{sim}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
edit.url = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sim: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sim: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sim: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sim: typeof args.sim === 'object'
                ? args.sim.id
                : args.sim,
                }

    return edit.definition.url
            .replace('{sim}', parsedArgs.sim.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
edit.get = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
edit.head = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
    const editForm = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
        editForm.get = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\SimController::edit
 * @see app/Http/Controllers/SimController.php:58
 * @route '/sims/{sim}/edit'
 */
        editForm.head = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
export const update = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put","patch"],
    url: '/sims/{sim}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
update.url = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sim: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sim: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sim: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sim: typeof args.sim === 'object'
                ? args.sim.id
                : args.sim,
                }

    return update.definition.url
            .replace('{sim}', parsedArgs.sim.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
update.put = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
update.patch = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
    const updateForm = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
        updateForm.put = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\SimController::update
 * @see app/Http/Controllers/SimController.php:68
 * @route '/sims/{sim}'
 */
        updateForm.patch = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\SimController::destroy
 * @see app/Http/Controllers/SimController.php:78
 * @route '/sims/{sim}'
 */
export const destroy = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/sims/{sim}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\SimController::destroy
 * @see app/Http/Controllers/SimController.php:78
 * @route '/sims/{sim}'
 */
destroy.url = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { sim: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { sim: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    sim: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        sim: typeof args.sim === 'object'
                ? args.sim.id
                : args.sim,
                }

    return destroy.definition.url
            .replace('{sim}', parsedArgs.sim.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\SimController::destroy
 * @see app/Http/Controllers/SimController.php:78
 * @route '/sims/{sim}'
 */
destroy.delete = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\SimController::destroy
 * @see app/Http/Controllers/SimController.php:78
 * @route '/sims/{sim}'
 */
    const destroyForm = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\SimController::destroy
 * @see app/Http/Controllers/SimController.php:78
 * @route '/sims/{sim}'
 */
        destroyForm.delete = (args: { sim: number | { id: number } } | [sim: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const SimController = { index, create, store, show, edit, update, destroy }

export default SimController